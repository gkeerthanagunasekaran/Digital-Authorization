# digital_Authorization_
This System of Digital Authorization provide the students or staffs of an particular organization to request leave or ON DUTY via online . Where the usual formality of writing letters and getting signature from a particular official will be avoided .which will save the time of both the higher official and the students or staffs who requests it.   
